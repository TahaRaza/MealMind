export default {
  primary: '#ffe5ba', // Light yellow shade
  background: '#ffffff',
  text: '#622906', // Dark brown shade
  accent: '#ff9800',
  box: '#622906', // Dark brown shade
};
